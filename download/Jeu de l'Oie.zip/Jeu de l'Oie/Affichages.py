# Modules importés
import tkinter as tk
import os

# Afficher une image
def image(nom, pady, frame):
    chemin_image = os.path.join(os.path.dirname(os.path.abspath(__file__)), "images", nom)
    image = tk.PhotoImage(file=chemin_image)
    image_label = tk.Label(frame, image=image)
    image_label.image = image
    image_label.pack(pady=pady)

# Afficher un texte
def texte(texte, font, pady, frame):
    txt = tk.Label(frame, text=texte, font=font)
    txt.pack(pady=pady)
    return txt

# Créer un bouton
def bouton(texte, commande, couleur, taille, police, frame, pady):
    bouton = tk.Button(frame)
    bouton.config(text=texte, command=commande, width=taille[0], height=taille[1], 
                  font=police, bg=couleur, fg="white")
    
    bouton.bind("<Enter>", lambda e: e.widget.configure(background=f"dark{couleur}"))
    bouton.bind("<Leave>", lambda e: e.widget.configure(background=couleur))
    
    bouton.pack(pady=pady)
    return bouton

# Créer un carré
def creer_carre(parent):
    frame = tk.Frame(parent, width=50, height=50, bg='#0066cc')
    frame.pack_propagate(False)  # Empêche le frame de s'ajuster à son contenu
    frame.pack(side=tk.LEFT, padx=10)
        
    label = tk.Label(frame, text="", font=("Arial", 18, "bold"), bg='#0066cc', fg='white')
    label.pack(expand=True)
        
    return label

# Créer une zone de visuels
def creer_canvas(parent, width=500, height=500, bg='white'):
    canvas = tk.Canvas(parent, width=width, height=height, bg=bg, highlightthickness=0)
    canvas.pack(pady=20)
    return canvas
