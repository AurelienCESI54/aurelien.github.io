# Modules importés
import os, json, tkinter as tk
from json.decoder import JSONDecodeError

# Créer une fenêtre
def new_fenetre(titre, taille, resize, fenetre=None):
    if fenetre is None:
        fenetre = tk.Tk()  # Crée une nouvelle fenêtre seulement si aucune n'est fournie
    
    fenetre.title(titre)
    fenetre.geometry(taille)
    fenetre.resizable(width=resize, height=resize)
    return fenetre

# Charger des images
def load_PNG(PNGS):
    images = {}

    for pict in PNGS:
        image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "images", pict)
        images[pict] = tk.PhotoImage(file=image_path)
    return images

# Charger un fichier JSON
def load_JSON(JSON):
    regles = []

    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), JSON), 'r', encoding='utf-8') as file:
            regles = json.load(file)
    except FileNotFoundError:
        print("Erreur : Le fichier ", JSON, " n'a pas été trouvé.")
    except JSONDecodeError:
        print("Erreur : Le fichier ", JSON, " est mal formaté.")
    
    return regles

# Calculs de coordonnées
def calculer_coordonnees(numero_case, largeur_canvas, marge):
    taille_case = (largeur_canvas - 2 * marge) // 8
    x = marge + ((numero_case - 1) % 8) * taille_case + taille_case // 2
    y = marge + ((numero_case - 1) // 8) * taille_case + taille_case // 2
    return x, y

# Calculs de directions pour une forme de spirale
def direction(index):
    largeur_canvas = 500
    marge = 20
    taille_case = (largeur_canvas - 2 * marge) // 8

    # Définir les directions
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    direction_index = 0

    x, y = 0, 0
    cases_restantes = 8
    longueur_cote = 8

    for i in range(1, index):
        cases_restantes -= 1

        if cases_restantes == 0:
            direction_index = (direction_index + 1) % 4
            longueur_cote -= (direction_index % 2)  # Réduire la longueur tous les deux côtés
            cases_restantes = longueur_cote

        dx, dy = directions[direction_index]
        x += dx
        y += dy

    x = marge + x * taille_case + taille_case // 2
    y = marge + y * taille_case + taille_case // 2

    return x, y

# Gerer les règles générales de déplacement (63, deux joueurs)
def gerer_deplacement(joueur, ancienne_position, nouvelle_position, joueurs, deplacer_pion, terminer_partie):
    # Règles du 63
    if nouvelle_position == 63:
        terminer_partie(joueur.numero)
        return nouvelle_position
    elif nouvelle_position > 63:
        nouvelle_position = 63 - (nouvelle_position - 63)
    
    # Vérifier si un autre joueur est sur la nouvelle position
    for j in joueurs:
        if j != joueur and j.position == nouvelle_position:
            # Échanger les positions
            j.position = ancienne_position
            deplacer_pion(joueurs.index(j), ancienne_position)
            break

    # Mettre à jour la position du joueur actuel
    joueur.position = nouvelle_position
    deplacer_pion(joueurs.index(joueur), nouvelle_position)
    
    return nouvelle_position

# Vérifier si la case se trouve dans le fichier de règles
def verifier_regles_speciales(nouvelle_position, regles, messagebox):
    regle = regles.get(str(nouvelle_position))
    if regle:
        nom_regle, message = regle
        messagebox.showinfo(nom_regle, message)
        return nouvelle_position
    return None
