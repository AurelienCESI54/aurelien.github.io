# Modules importés
import tkinter as tk, random
from tkinter import messagebox

import Affichages, Affichages_Codes, Mecaniques
from GameOver import lancer_partie_terminee # Méthode de GameOver.py

# Elements du joueur
class Joueur:
    def __init__(self, numero):
        self.numero = numero
        self.position = 0
        self.passe = False
        self.wait = False

# Elements du jeu de l'oie
class PlateauJeu:
    def __init__(self, fenetre_existante, nb_joueurs):
        self.fenetre = fenetre_existante
        self.nombre_joueurs = nb_joueurs
        self.joueurs = [Joueur(i + 1) for i in range(nb_joueurs)]
        self.joueur_actuel = 0
        self.des_lances = False
        self.effet_special = None
        self.resultat = 0
        self.load()
        self.setup_ui()

# PARTIE GRAPHIQUE / VISUEL -----------------------------------------------------------------------------------------------------------------------------------------------

    # Charger les éléments utilisés
    def load(self):
        self.images = Mecaniques.load_PNG(["oie.png", "black.png", "pont.png", "hotel.png", "puit.png", "laby.png", "prison.png", "mort.png", "eau.png"])
        self.regles = Mecaniques.load_JSON('Rules.json')

    # Fabriquer le plateau en spirale
    def creer_plateau(self, canvas):
        cases = 64
        largeur_canvas = 500
        marge = 20
        taille_case = (largeur_canvas - 2 * marge) // 8

        x, y = marge, marge

        for i in range(cases):
            # Calculer les coordonnées du centre de la case
            x_coord, y_coord = Mecaniques.direction(i + 1)

            # Dessiner le rectangle
            canvas.create_rectangle(x_coord - taille_case // 2,
                                    y_coord - taille_case // 2,
                                    x_coord + taille_case // 2,
                                    y_coord + taille_case // 2,
                                    fill='white', outline='black')
            
            # Ajouter le texte centré dans la case
            canvas.create_text(x_coord, y_coord,
                            text=str(i + 1), font=('Arial', 10))

            x_coord, y_coord = Mecaniques.direction(i + 1)
            x, y = x_coord - taille_case // 2, y_coord - taille_case // 2

    # Case = Position Element
    def case_to_coordinates(self, numero_case):
        return Mecaniques.direction(numero_case)

    # Décorer les cases
    def placer_image_sur_cases(self, element, cases):
        for c in cases:
            x, y = self.case_to_coordinates(c)
            self.canvas.create_image(x, y, image=self.images[element], anchor=tk.CENTER)
    
    # Afficher les éléments
    def setup_ui(self):
        self.fenetre = Mecaniques.new_fenetre("Jeu de l'oie", "700x700", False, self.fenetre)
        
        self.contenu_frame = tk.Frame(self.fenetre)
        self.contenu_frame.pack(fill="both", expand=True)

        self.creer_plateau_ui()
        self.bouton_lancer, self.bouton_next, self.label_joueur, self.label_resultat1, self.label_resultat2, self.label_position = Affichages_Codes.configurer_elements_interactifs(self.fenetre, self.joueurs, self.tour, self.next_action)

    # Elements du plateau
    def creer_plateau_ui(self):
        # Plateau
        self.canvas = Affichages.creer_canvas(self.contenu_frame, width=500, height=500, bg='white')
        self.creer_plateau(self.canvas)
    
        # Décors
        images_et_cases = {"pont.png": [6], "hotel.png": [19], "puit.png": [31], "laby.png": [42], "prison.png": [52], "mort.png": [58], "eau.png": [63], "black.png": [64], "oie.png": [9, 18, 27, 36, 45, 54]}

        for image, cases in images_et_cases.items():
            self.placer_image_sur_cases(image, cases)

        # Pions
        couleurs = ['red', 'blue', 'green', 'yellow']
        self.pions = []
        
        for p in range(self.nombre_joueurs):
            x, y = 25, 25 + p * 8
            pion = self.canvas.create_oval(x, y, x + 30, y + 30, fill=couleurs[p])
            self.pions.append(pion)

# PARTIE GAMEPLAY / MOTEUR -----------------------------------------------------------------------------------------------------------------------------------------------

    # Définir le tour de jeu
    def tour(self):
        # Lancer impossible si déjà lancer
        if self.des_lances:
            messagebox.showwarning("Action non autorisée", "Vous avez déjà lancé les dés")
            return

        # Etats du joueur actuel + Lancer de dés
        joueur = self.joueurs[self.joueur_actuel]

        if joueur.wait:
            messagebox.showinfo("En attente...", "Vous êtes coincé. Veuillez attendre qu'un autre joueur vous délivre.")
            self.des_lances = True
            self.bouton_next.config(state=tk.NORMAL)
            self.bouton_lancer.config(state=tk.DISABLED)
            return
        elif joueur.passe:
            resultat1 = 0
            resultat2 = 0
            messagebox.showinfo("Tour passé", "Vous passez votre tour.")
            joueur.passe = False
            nouvelle_position = Mecaniques.gerer_deplacement(joueur, joueur.position, joueur.position + 1, self.joueurs, self.deplacer_pion, self.terminer_partie)
        else:
            try:
                resultat1 = random.randint(1, 6)
                resultat2 = random.randint(1, 6)
            except Exception as e:
                messagebox.showerror("Erreur", f"Problème lors du lancement des dés : {str(e)}")
                return

        self.resultat = resultat1 + resultat2
        self.label_resultat1.config(text=f"{resultat1}")
        self.label_resultat2.config(text=f"{resultat2}")

        # Mettre à jour les positions
        ancienne_position = joueur.position
        nouvelle_position = Mecaniques.gerer_deplacement(joueur, ancienne_position, ancienne_position + resultat1 + resultat2, self.joueurs, self.deplacer_pion, self.terminer_partie)

        # Libéré de l'attente ---WIP---UNFINISHED---
        for j in self.joueurs:
            if j != joueur and j.position == nouvelle_position and j.wait:
                j.wait = False
                messagebox.showinfo("Délivrance", f"Le joueur {j.numero} a été délivré !")
                joueur.wait = True
                break

        # Appliquer les effets
        self.effet_special = Mecaniques.verifier_regles_speciales(nouvelle_position, self.regles, messagebox)
        self.appliquer_effet_special()

        # Passer au joueur suivant
        self.des_lances = Affichages_Codes.mettre_a_jour_interface(self.label_position, self.des_lances, self.bouton_next, self.bouton_lancer, joueur)

    # Afficher le déplacement du pion
    def deplacer_pion(self, index_joueur, nouvelle_position):
        try:
            x, y = self.position_to_coordinates(nouvelle_position)
            taille_case = (500 - 2 * 20) // 8 
            rayon_pion = 15
            self.canvas.coords(self.pions[index_joueur], 
                            x - rayon_pion, y - rayon_pion, 
                            x + rayon_pion, y + rayon_pion)
        except ValueError:
            messagebox.showerror("Erreur", "Position invalide sur le plateau")

    # Position du joueur = Coordonnées du pion
    def position_to_coordinates(self, position):
        x, y = Mecaniques.direction(position)
        return x, y

    # Règles
    def appliquer_effet_special(self):
        if self.effet_special:
            regle = self.regles.get(str(self.effet_special))
            if regle:
                nom_regle, message = regle
                if nom_regle == "Pont":
                    self.joueurs[self.joueur_actuel].position = 12
                    self.deplacer_pion(self.joueur_actuel, 12)
                elif nom_regle == "Hôtel" :
                    self.joueurs[self.joueur_actuel].passe = True
                elif nom_regle == "Puits":
                    self.joueurs[self.joueur_actuel].wait = True
                elif nom_regle == "Labyrinthe":
                    self.joueurs[self.joueur_actuel].position = 30
                    self.deplacer_pion(self.joueur_actuel, 30)
                elif nom_regle == "Prison":
                    self.joueurs[self.joueur_actuel].wait = True
                elif nom_regle == "Mort":
                    self.joueurs[self.joueur_actuel].position = 1
                    self.deplacer_pion(self.joueur_actuel, 1)
                elif nom_regle == "Oie":
                    ancienne_position = self.joueurs[self.joueur_actuel].position
                    nouvelle_position = ancienne_position + self.resultat
                    nouvelle_position = Mecaniques.gerer_deplacement(self.joueurs[self.joueur_actuel], ancienne_position, nouvelle_position, self.joueurs, self.deplacer_pion, self.terminer_partie)
                self.effet_special = None

    # Passer au suivant
    def next_action(self):
        if not self.des_lances:
            messagebox.showwarning("Action non autorisée", "Vous devez d'abord lancer les dés !")
            return

        self.joueur_actuel = (self.joueur_actuel + 1) % self.nombre_joueurs
        self.label_joueur.config(text=f"Joueur {self.joueurs[self.joueur_actuel].numero}")
        self.label_resultat1.config(text="")
        self.label_resultat2.config(text="")
        
        self.des_lances = False
        self.bouton_next.config(state=tk.DISABLED)
        self.bouton_lancer.config(state=tk.NORMAL)

    # Fin de partie
    def terminer_partie(self, numero_gagnant):
        try:
            for widget in self.fenetre.winfo_children():
                widget.destroy()
            lancer_partie_terminee(self.fenetre, numero_gagnant, self.nombre_joueurs)
        finally:
            pass

# FIN --------------------------------------------------------------------------------------------------------------------------------------------------------------------

def lancer_plateau(fenetre_existante, nb_joueurs):
    PlateauJeu(fenetre_existante, nb_joueurs)

if __name__ == "__main__":
    root = tk.Tk()
    lancer_plateau(root, 1)
    root.mainloop()
