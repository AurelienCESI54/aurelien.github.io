# Modules importés
import tkinter as tk, random
import Accueil, Affichages

class FenetrePartieTerminee:
    def __init__(self, master, numero_gagnant, nombre_joueurs):
        self.master = master
        self.creer_fenetre()
        self.create_widgets(numero_gagnant, nombre_joueurs)

    def creer_fenetre(self):
        self.master.title("Partie Terminée")

    # Lancer une nouvelle partie
    def nouvelle_partie(self):
        for widget in self.master.winfo_children():
            widget.destroy()
        Accueil.JeuDeLoie(self.master)

    # Créer les éléments
    def create_widgets(self, numero_gagnant, nombre_joueurs):
        # Fenêtre
        self.contenu_frame = tk.Frame(self.master)
        self.contenu_frame.pack(fill="both", expand=True)

        # Message de fin
        if nombre_joueurs == 1:
            message = "Vous avez gagné !"
        else:
            message = f"Joueur {numero_gagnant} a gagné !"

        Affichages.texte(message, ("Arial", 40), (200, 20), self.contenu_frame)

        # Boutons Nouvelle Partie et Quitter
        Affichages.bouton("Nouvelle Partie", self.nouvelle_partie, "green", (15, 2), ("Arial", 14), self.contenu_frame, (30, 0))
        Affichages.bouton("Quitter", self.master.quit, "red", (15, 2), ("Arial", 14), self.contenu_frame, (30, 0))

def lancer_partie_terminee(fenetre=None, numero_gagnant=None, nombre_joueurs=1):
    if fenetre is None:
        fenetre = tk.Tk()
    FenetrePartieTerminee(fenetre, numero_gagnant, nombre_joueurs)
    fenetre.mainloop()

# Simulation
def simuler_fin_partie(nombre_joueurs):
    return random.randint(1, nombre_joueurs)

if __name__ == "__main__":
    nombre_joueurs = 1
    gagnant = simuler_fin_partie(nombre_joueurs)
    lancer_partie_terminee(numero_gagnant=gagnant, nombre_joueurs=nombre_joueurs)
