# Modules importés
import tkinter as tk, Affichages

# Créer les boutons de sélection de joueurs
def creer_boutons_joueurs(frame, nombre_de_boutons, commande):
    boutons_frame = tk.Frame(frame)
    boutons_frame.pack()

    boutons = []
    for i in range(nombre_de_boutons):
        nouveau_bouton = Affichages.bouton(str(i + 1), lambda x=i + 1: commande(x, boutons), "blue", (5, 2), ("Arial", 14), boutons_frame, 0)
        nouveau_bouton.pack(side="left", padx=10)
        boutons.append(nouveau_bouton)

    return boutons

# Créer les éléments de l'interface de jeu
def configurer_elements_interactifs(fenetre, joueurs, lancer_des, next_action):
    # Cadre pour les boutons
    cadre_boutons = tk.Frame(fenetre)
    cadre_boutons.pack(side=tk.BOTTOM, fill=tk.X, pady=20)

    # Cadre pour le joueur et les dés
    cadre_joueur_des = tk.Frame(cadre_boutons)
    cadre_joueur_des.pack(side=tk.LEFT, padx=20)

    # Joueur actuel
    label_joueur = Affichages.texte(f"Joueur {joueurs[0].numero}", font=("Arial", 14, "bold"), pady=(0, 5), frame=cadre_joueur_des)

    # Bouton Lancer
    bouton_lancer = Affichages.bouton("Lance les dés", lancer_des, "blue", (15, 2), ("Arial", 14), cadre_joueur_des, pady=5)

    # Dés
    label_resultat1 = Affichages.creer_carre(cadre_boutons)
    label_resultat2 = Affichages.creer_carre(cadre_boutons)

    # Position
    label_position = Affichages.texte("Position: 0", font=("Arial", 14), pady=5, frame=cadre_boutons)

    # Bouton Next
    bouton_next = Affichages.bouton("Next", next_action, "blue", (15, 2), ("Arial", 14), cadre_boutons, pady=20)

    return bouton_lancer, bouton_next, label_joueur, label_resultat1, label_resultat2, label_position

# Mettre à jour les éléments de l'interface
def mettre_a_jour_interface(label_position, des_lances, bouton_next, bouton_lancer, joueur):
    # Afficher la nouvelle position
    label_position.config(text=f"Position: {joueur.position}")
    
    des_lances = True
    bouton_next.config(state=tk.NORMAL)
    bouton_lancer.config(state=tk.DISABLED)
    
    return des_lances
