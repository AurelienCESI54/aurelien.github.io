# Modules importés
import tkinter as tk
import Plateau, Affichages, Mecaniques, Affichages_Codes

class JeuDeLoie:
    def __init__(self, fenetre_existante=None):
        self.nombre_joueurs_selectionne = 2
        self.fenetre = Mecaniques.new_fenetre("Jeu de l'oie", "700x700", False, fenetre_existante)
        self.create_widgets()

    # Créations des éléments de la fenêtre
    def create_widgets(self):
        # Frame
        contenu_frame = tk.Frame(self.fenetre)
        contenu_frame.pack(fill="both", expand=True)

        # Titre et Texte
        Affichages.image("title.png", (20, 40), contenu_frame)
        Affichages.texte("Nombre de joueurs", ("Arial", 24), (0, 20), contenu_frame)
        
        # Boutons Nombres de Joueurs
        self.boutons_frame = tk.Frame(contenu_frame)
        self.boutons_frame.pack()
        self.boutons = Affichages_Codes.creer_boutons_joueurs(self.boutons_frame, 4, self.nombre_joueurs)
        
        # Bouton Joueur et Quitter
        Affichages.bouton("Play", lambda: self.start(), "green", (10, 2), ("Arial", 14), contenu_frame, (30, 0))
        Affichages.bouton("Quitter", self.fenetre.quit, "red", (10, 2), ("Arial", 14), contenu_frame, (30, 0))

    # Enregistrer le nombre de joueurs
    def nombre_joueurs(self, numero, boutons):
        self.nombre_joueurs_selectionne = numero
    
        for i, bouton in enumerate(boutons):
            if i + 1 == numero:
                bouton.config(bg="darkblue")
                bouton.unbind("<Enter>")
                bouton.unbind("<Leave>")
            else:
                bouton.config(bg="blue")
                bouton.bind("<Enter>", lambda e, b=bouton: b.config(bg="darkblue"))
                bouton.bind("<Leave>", lambda e, b=bouton: b.config(bg="blue"))

    # Lancer le jeu
    def start(self):
        for widget in self.fenetre.winfo_children():
            widget.destroy()
        Plateau.lancer_plateau(self.fenetre, self.nombre_joueurs_selectionne)

if __name__ == "__main__":
    jeu = JeuDeLoie()
    jeu.fenetre.mainloop()
