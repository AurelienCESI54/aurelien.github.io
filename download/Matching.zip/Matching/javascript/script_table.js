// Définition des données
const tableHeaders = [
    'Nom de l\'événement', 
    'Type', 
    'Artiste', 
    'Date', 
    'Horaire', 
    'Lieu', 
    'Âge', 
    'Prix', 
    'Billets'
];

const tableData = [
    {
        eventName: 'Concert Rock',
        type: 'Musique',
        artist: 'The Rockers',
        date: '15/02/2025',
        time: '20:00',
        place: 'Zénith de Paris',
        age: '18+',
        price: '45€',
        tickets: Math.floor(Math.random() * 6)
    },
    {
        eventName: 'Festival Jazz',
        type: 'Musique',
        artist: 'Jazz Ensemble',
        date: '22/03/2025',
        time: '19:30',
        place: 'Olympia',
        age: '16+',
        price: '35€',
        tickets: Math.floor(Math.random() * 6)
    },
    {
        eventName: 'Spectacle Comique',
        type: 'Humour',
        artist: 'Comedien Star',
        date: '10/04/2025',
        time: '21:00',
        place: 'Palais des Congrès',
        age: '16+',
        price: '55€',
        tickets: Math.floor(Math.random() * 6)
    },
    {
        eventName: 'KAZY LAMBIST + COURRIER SUD',
        type: 'Electro-Pop',
        artist: 'KAZY LAMBIST',
        date: '23/01/2025',
        time: '19:30',
        place: 'Rockstore, Montpellier',
        age: '18+',
        price: '15€',
        tickets: Math.floor(Math.random() * 6)
    },
    {
        eventName: 'AÏTA MON AMOUR',
        type: 'Maghreb Pop',
        artist: 'AÏTA MON AMOUR',
        date: '24/01/2025',
        time: '19:30',
        place: 'Rockstore, Montpellier',
        age: '18+',
        price: '20€',
        tickets: Math.floor(Math.random() * 6)
    },
    {
        eventName: 'AVALON BLOOM',
        type: 'Rock Alternatif',
        artist: 'AVALON BLOOM',
        date: '25/01/2025',
        time: '19:30',
        place: 'Rockstore, Montpellier',
        age: '18+',
        price: '0€',
        tickets: Math.floor(Math.random() * 6)
    }
];

// Fonction pour générer le tableau
function generateTable() {
    const tableContainer = document.getElementById('tableContainer');
    const table = document.createElement('table');
    table.className = 'table';

    // Création de l'en-tête
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    
    tableHeaders.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
    });
    
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Création du corps du tableau
    const tbody = document.createElement('tbody');
    
    tableData.forEach(event => {
        const row = document.createElement('tr');
        
        // Insertion des données dans le nouvel ordre
        [
            event.eventName, 
            event.type, 
            event.artist, 
            event.date, 
            event.time, 
            event.place, 
            event.age || '18+', 
            event.price,
            event.tickets !== undefined ? event.tickets : Math.floor(Math.random() * 6)
        ].forEach(cellData => {
            const td = document.createElement('td');
            td.textContent = cellData;
            row.appendChild(td);
        });
        
        tbody.appendChild(row);
    });

    table.appendChild(tbody);
    tableContainer.innerHTML = ''; // Nettoie le conteneur
    tableContainer.appendChild(table);
}

// Appel de la fonction au chargement de la page
document.addEventListener('DOMContentLoaded', generateTable);
