function createHeader(title) {
    return `
    <div style="display: flex; align-items: center; justify-content: space-between; padding: 10px;">
        <div id="Title" class="titre">
            <u><b>${title}</b></u>
        </div>
        <div style="text-align: right;">
            <img src="../images/logo_alt.png" alt="Logo_site" style="width: 150px; height: auto;">
        </div>
    </div>
    `;
}
