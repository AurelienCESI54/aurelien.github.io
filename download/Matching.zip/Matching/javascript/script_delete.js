// Enlever tous les éléments renseignés du formulaire
function resetForm(name) {
    const form = document.getElementById(name);
    form.reset();
}