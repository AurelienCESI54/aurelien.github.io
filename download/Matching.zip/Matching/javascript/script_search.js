const search = document.getElementById('event_light_search');
const select = document.getElementById('NomEvent');

search.addEventListener('input', function() {
    const searchText = this.value.toLowerCase();
    const options = select.querySelectorAll('option');
    let visibleOptionsCount = 0;

    options.forEach(option => {
        if (option.value === "") return; // Ignorer l'option par défaut
        const optionText = option.textContent.toLowerCase();
        const isVisible = optionText.includes(searchText);
        option.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleOptionsCount++;
    });

    if (visibleOptionsCount === 0) {
        // Sauvegarder les options
        const originalOptions = Array.from(select.options);
        select.innerHTML = '<option value="">Aucun résultat</option>';
        // Restaurer les options
        setTimeout(() => {
            select.innerHTML = '';
            originalOptions.forEach(opt => select.appendChild(opt));
        }, 10);
    } else {
        if (select.selectedOptions[0] && select.selectedOptions[0].style.display === 'none') {
            select.value = "";
        }
    }
});
