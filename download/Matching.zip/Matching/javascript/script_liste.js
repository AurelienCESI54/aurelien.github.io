// Liste
function createDropdown(name, labelText, options) {
    const selectId = name.replace(/\s+/g, '');
    let optionsHtml = '<option value="" selected disabled>Sélectionner...</option>';
    
    options.forEach(option => {
        optionsHtml += `<option value="${option}">${option}</option>`;
    });

    return `
        <label for="${selectId}">${labelText} :</label>
        <select id="${selectId}" name="${name}" required>
            ${optionsHtml}
        </select>
    `;
}

// Checkbox
function createCheckboxGroup(name, labelText, options, initiallyHidden = false) {
    const groupId = name.replace(/\s+/g, '');
    let checkboxesHtml = '';
    
    options.forEach((option, index) => {
        const optionId = `${groupId}_${index}`;
        checkboxesHtml += `
            <div>
                <input type="checkbox" id="${optionId}" name="${name}" value="${option}" onchange="updateSelectedArtists('${name}')">
                <label for="${optionId}">${option}</label>
            </div>
        `;
    });

    const toggleId = `${groupId}_toggle`;
    
    return `
        <fieldset>
            <legend>
                ${labelText} :
                <button type="button" id="${toggleId}" onclick="(function() { toggleOptions('${groupId}'); })()">
                    ${initiallyHidden ? 'Afficher' : 'Masquer'} les options
                </button>
            </legend>
            <div id="${groupId}_options" ${initiallyHidden ? 'style="display: none;"' : ''}>
                ${checkboxesHtml}
            </div>
        </fieldset>
    `;
}

// Options on/off
function toggleOptions(groupId) {
    const optionsDiv = document.getElementById(groupId + '_options');
    const toggleButton = document.getElementById(groupId + '_toggle');
    if (optionsDiv.style.display === 'none') {
        optionsDiv.style.display = 'block';
        toggleButton.textContent = 'Masquer les options';
    } else {
        optionsDiv.style.display = 'none';
        toggleButton.textContent = 'Afficher les options';
    }
}

// Débug : sélectionner les artistes
function updateSelectedArtists(name) {
    const checkboxes = document.querySelectorAll(`input[name="${name}"]:checked`);
    const selectedArtists = Array.from(checkboxes).map(cb => cb.value);
    console.log("Artistes : " + selectedArtists.join(", "));
}