// Script permettant la sauvegarde des nouvelles données dans une base.
// L'idée : Si élément pas dans la liste, cliquer sur "Ajouter", remplir le champs, qui ajoute à la liste et sauvegarde.
document.addEventListener('DOMContentLoaded', function() {
    let jsonData = {
        "Artiste": ["JeanPaul", "CESI"],
        "Place": ["MFC", "10, Rue Machin, Ville_Pomé"]
    };

    function populateSelect(selectId, data) {
        const select = document.getElementById(selectId);
        data.forEach(item => {
            let option = document.createElement('option');
            option.value = item;
            option.textContent = item;
            select.appendChild(option);
        });
        let addOption = document.createElement('option');
        addOption.value = 'Ajouter';
        addOption.textContent = 'Ajouter';
        select.appendChild(addOption);
    }

    populateSelect('Artiste', jsonData.Artiste);
    populateSelect('Place', jsonData.Place);

    function handleSelectChange(selectId, inputId) {
        const select = document.getElementById(selectId);
        const input = document.getElementById(inputId);
        select.addEventListener('change', function() {
            if (this.value === 'Ajouter') {
                this.style.display = 'none';
                input.style.display = 'inline-block';
                input.focus();
            }
        });

        input.addEventListener('blur', function() {
            if (this.value.trim() !== '') {
                let newOption = document.createElement('option');
                newOption.value = this.value;
                newOption.textContent = this.value;
                select.insertBefore(newOption, select.lastElementChild);
                select.value = this.value;
                jsonData[selectId].push(this.value);
                // Ici, vous devriez implémenter la logique pour mettre à jour le fichier JSON côté serveur
                console.log('Mise à jour du JSON :', JSON.stringify(jsonData));
            }
            this.style.display = 'none';
            select.style.display = 'inline-block';
        });
    }

    handleSelectChange('Artiste', 'ArtisteInput');
    handleSelectChange('Place', 'PlaceInput');
});
